import webbrowser
import os
import re

# Styles and scripting for the page
main_page_head = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Films Vault</title>

    <!-- Bootstrap 3 -->
    <link rel="stylesheet"
    href="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css">
    <link rel="stylesheet"
    href="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap-theme.min.css"> <!-- # NOQA -->
    <script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
    <script src="https://netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"> <!-- # NOQA -->
    </script>
    <style type="text/css" media="screen">
        body {
            padding-top: 80px;
            background-color: black;
        }
        #trailer .modal-dialog {
            margin-top: 200px;
            width: 640px;
            height: 580px;
        }
        .hanging-close {
            position: absolute;
            top: -12px;
            right: -12px;
            z-index: 9001;
        }
        #trailer-video {
            width: 100%;
            height: 100%;
        }
        .film-tile {
            margin-bottom: 20px;
            padding-top: 20px;
        }
        .film-tile:hover {
            background-color: #bebebe;
            cursor: pointer;
        }
        .scale-media {
            padding-bottom: 56.25%;
            position: relative;
        }
        .scale-media iframe {
            border: none;
            height: 100%;
            position: absolute;
            width: 100%;
            left: 0;
            top: 0;
            background-color: black;
        }
        /* Add a gray color and text to the footer */
        footer {
            background-color: white;
            padding: 18px;
        }
    </style>
    <script type="text/javascript" charset="utf-8">
        // Pause the video when the modal is closed
        $(document).on('click', '.hanging-close, .modal-backdrop, .modal', 
                       function (event) {
                                 // Remove the src so the player itself gets
                                 // removed, as this is the only reliable
                                 //  way to ensure the video stops playing in IE
                                 $("#trailer-video-container").empty();
                       });
        // Start playing the video whenever the trailer modal is opened
        $(document).on('click', '.film-tile', function (event) {
            var trailerYouTubeId = $(this).attr('data-trailer-youtube-id')
            var sourceUrl = 'http://www.youtube.com/embed/' + trailerYouTubeId +
            '?autoplay=1&html5=1';
            $("#trailer-video-container").empty().append($("<iframe></iframe>", {
              'id': 'trailer-video',
              'type': 'text-html',
              'src': sourceUrl,
              'frameborder': 0
            }));
        });
        // Animate in the films when the page loads
        $(document).ready(function () {
          $('.film-tile').hide().first().show("fast", function showNext() {
            $(this).next("div").show("fast", showNext);
          });
        });
        // Show storyline when the mouse is over the title
        // Function copied from W3Schools.com 
        // (https://www.w3schools.com/bootstrap/bootstrap_popover.asp)
        $(document).ready(function(){
            $('[data-toggle="popover"]').popover({
                placement : 'top',
                trigger : 'hover'
            });
        });
    </script>
</head>
'''


# The main page layout and title bar (Left side/first
# section - selected movies list)

main_page_content = '''
  <body>
    <!-- Trailer Video Modal -->
    <div class="modal" id="trailer">
      <div class="modal-dialog">
        <div class="modal-content">
          <a href="#" class="hanging-close" data-dismiss="modal" 
          aria-hidden="true"> 
            <img src="https://lh5.ggpht.com/v4-628SilF0HtHuHdu5EzxD7WRqOrrTIDi_MhEG6_qkNtUK5Wg7KPkofp_VJoF7RS2LhxwEFCO1ICHZlc-o_=s0#w=24&h=24"/> <!-- # NOQA -->
          </a>
          <div class="scale-media" id="trailer-video-container">
          </div>
        </div>
      </div>
    </div>

    <!-- Main Page Content -->
    <div class="container">
      <div class="navbar navbar-default navbar-fixed-top" role="navigation">
        <div class="container">
          <div class="navbar-header">
            <a class="navbar-brand" href="collection_listing.html">
                <!-- Icon on the left of site name -->
                <img 
                src="http://www.free-icons-download.net/images/movie-icon-72062.png"
                alt="" width="25" height="25" />
                  Films Vault - Trailers and Information</a>
          </div>
        </div>
      </div>

    <!-- Begin two columns design -->
    <div class="container">
        <div class="row">
            <div class="col-xs-7 col-sm-6
            col-lg-8"">
                {film_tiles}
            </div>
'''

# Second section - Top 15 list content (right side)
# and footer information

second_page_content = '''
            <div class="col-xs-5 col-sm-6 col-lg-4 sidebar"
            style="background-color:white" text-center>
                <h3>Top 15 Movies from IMDB</h3>
                <table>
                    <!-- Table head -->
                    <tr>
                        <th>Rank</th>
                        <th>Title</th>
                        <th>Release year</th>
                    </tr>
                    <!-- Table head ends -->
                    <!-- Top 15 list contents -->
                    {top_tiles}
                    <!-- Top 15 list contents ends -->
                </table>
            </div>
        </div>
    </div>
    <!-- End of two columns design -->
</div>

    <!-- Here goes the code for the footer -->
    <div>
        <footer class="container-fluid text-center">
            <p>
                Project Movie site
                <span class="glyphicon glyphicon-film"></span>
                | User: luiz_mn
            </p>
        </footer>
    </div>
    <!-- Footer code ends-->
  </body>
</html>
'''

# A single film entry html template
film_tile_content = r'''<div class="col-sm-6 film-tile text-center"
                    data-trailer-youtube-id="{trailer_youtube_id}"
                    data-toggle="modal" data-target="#trailer">
                            <img src="{poster}" width="220" height="342">
                            <a href="#" data-toggle="popover"
                                title="Release year: {film_release}"
                                data-content="{film_storyline}">
                                <h3>{film_title}</h3>
                            </a>
                        </div>'''

# A single top rated film entry html template
top_tile_content = '''
 <div class="col-sm-6 film-tile text-center text-primary">
        <tr>
            <td>{top_ranking} </td>
            <td>
                <h5>
                    <a href="http://www.imdb.com/title/{top_imdbid}"
                    target="_blank">{top_title}</a>
                </h5>
            </td>
            <td>
                <h5>{top_year}</h5>
            </td>
        </tr>
    </div>'''


def create_film_tiles_content(films):
    # The HTML content for this section of the page
    """
    Creates the film tiles from film instance and outputs in html
    format.
    """
    content = ''
    for film in films:
        # Extract the youtube ID from the url
        youtube_id_match = re.search(
            r'(?<=v=)[^&#]+', film.trailer)
        youtube_id_match = youtube_id_match or re.search(
            r'(?<=be/)[^&#]+', film.trailer)
        trailer_youtube_id = (youtube_id_match.group(0) if youtube_id_match
                              else None)

        # Append the tile for the film with its content filled in
        content += film_tile_content.format(
            film_title=film.title,
            film_storyline=film.storyline,
            poster=film.poster,
            trailer_youtube_id=trailer_youtube_id,
            film_release=film.release
        )

    return content


# Create top 15 movies list
def create_top_tiles_content(top_content):
    # The HTML content for the top 15 movies section of the page
    """
    Creates the top 15 movies table from IMDB via myapifilms
    API and outputs in html format.
    The input is the dict/list first generated in
    video_collection.py
    """
    top_list = ''
    # Select fields from dict top_content
    # In this case, just the ranking, title, year (of release)
    # and IMDB ID (for url formation) are needed

    for item in top_content["data"]["movies"]:
        # Append the tile for the film with its content filled in
        top_list = top_list+top_tile_content.format(
            top_ranking=item['ranking'],
            top_title=item['title'],
            top_year=item['year'],
            top_imdbid=item['idIMDB']
        )
    return top_list


def open_films_page(films, top_content):
    """
    Create html page with all the sections and displays it in
    a browser new tab, if possible.
    """
    # Create or overwrite the output file
    output_file = open('collection_listing.html', 'w')

    # Replace the film tiles placeholder generated content
    # Generate left side of page/first section
    rendered_content = main_page_content.format(
        film_tiles=create_film_tiles_content(films))

    # Generate right side of page/second section
    rendered_content_2 = second_page_content.format(
        top_tiles=create_top_tiles_content(top_content))

    # Output the file: writes first + second sections
    output_file.write(main_page_head + rendered_content + rendered_content_2)
    output_file.close()

    # open the output file in the browser (in a new tab, if possible)
    url = os.path.abspath(output_file.name)
    webbrowser.open('file://' + url, new=2)
